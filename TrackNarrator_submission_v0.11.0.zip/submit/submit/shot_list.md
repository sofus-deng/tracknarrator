# Shot List (Screens/Clips)
1) Terminal：執行 make demo，印出 session_id 與三個輸出檔。
2) cURL：/session/{id}/summary?ai_native=on 的部分 JSON。
3) Showcase：docs/index.html 載入 summary.json 後的「Top Events & Cards」。
4) KPIs 區段：Total Laps / Best / Median / Duration。
5) Zip 列表：export_zh.zip 與 export_en.zip。
備註：1080p/60fps；字體縮放約 125%；全部可離線重現。